"use client";

import { useParams, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { BOOKS } from "@/data/books";
import { isFavorite, toggleFavorite } from "@/services/favorites.service";
import { getReactions, like, dislike } from "@/services/reactions.service"; // Імпорт сервісу реакцій
import { ArrowLeft, Heart, ThumbsUp, ThumbsDown } from "lucide-react";

export default function BookPage() {
  const params = useParams();
  const router = useRouter();
  const id = Number(params.id);

  const book = BOOKS.find((b) => b.id === id);
  
  // Стейт для обраного (сердечко)
  const [fav, setFav] = useState(false);
  // Стейт для лайків/дизлайків
  const [reactions, setReactions] = useState({ like: 0, dislike: 0 });

  useEffect(() => {
    if (book) {
      setFav(isFavorite(book.id));
      setReactions(getReactions(book.id)); // Завантажуємо реакції при завантаженні
    }
  }, [book, id]);

  if (!book) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <h2 className="text-xl font-bold">Книгу не знайдено</h2>
        <button onClick={() => router.back()} className="text-blue-600 underline mt-2">
          Повернутися назад
        </button>
      </div>
    );
  }

  // Обробники кліків
  const handleLike = () => {
    like(book.id);
    setReactions(getReactions(book.id));
  };

  const handleDislike = () => {
    dislike(book.id);
    setReactions(getReactions(book.id));
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <button 
        onClick={() => router.back()}
        className="flex items-center gap-2 text-gray-600 hover:text-black transition"
      >
        <ArrowLeft size={20} />
        <span>Назад до каталогу</span>
      </button>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="space-y-4">
          {/* ЗОБРАЖЕННЯ З ФІКСОВАНОЮ ВИСОТОЮ */}
          <img
            src={book.cover}
            className="h-96 w-full object-cover rounded-xl border shadow-sm"
            alt={book.title}
          />

          <button className="w-full bg-blue-600 text-white py-2.5 rounded-lg font-medium hover:bg-blue-700 transition">
            Читати книгу
          </button>

          {/* Блок лайків/дизлайків */}
          <div className="flex justify-center gap-4 py-2 bg-gray-50 rounded-xl border">
            <button 
              onClick={handleLike}
              className="flex items-center gap-2 px-4 py-2 hover:bg-green-100 rounded-lg transition text-green-700"
            >
              <ThumbsUp size={20} /> <span>{reactions.like}</span>
            </button>
            <button 
              onClick={handleDislike}
              className="flex items-center gap-2 px-4 py-2 hover:bg-red-100 rounded-lg transition text-red-700"
            >
              <ThumbsDown size={20} /> <span>{reactions.dislike}</span>
            </button>
          </div>

          <div className="bg-white border rounded-xl p-4 space-y-2 text-sm shadow-sm">
            <div className="font-semibold text-gray-700 border-b pb-2 mb-2">Деталі книги</div>
            <div className="flex justify-between">
              <span className="text-gray-500">Автор:</span>
              <span className="font-medium">{book.author}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Рік:</span>
              <span className="font-medium">{book.year}</span>
            </div>
          </div>
        </div>

        <div className="md:col-span-2 space-y-4">
          <div className="flex justify-between items-start gap-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">{book.title}</h1>
              <div className="text-lg text-gray-500 mt-1">{book.author}</div>
            </div>

            <button
              onClick={() => {
                toggleFavorite(book);
                setFav(!fav);
              }}
              className={`p-2 rounded-full border transition-all ${
                fav 
                  ? "bg-red-50 border-red-200 text-red-500 shadow-sm" 
                  : "bg-white border-gray-200 text-gray-400 hover:bg-gray-50"
              }`}
            >
              <Heart size={28} fill={fav ? "currentColor" : "none"} />
            </button>
          </div>
  
          <div className="bg-white border rounded-xl p-5 shadow-sm">
            <div className="font-semibold text-gray-800 mb-2">Опис</div>
            <p className="text-gray-600 leading-relaxed">
              {book.description || "Опис для цієї книги поки що відсутній."}
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            {book.tags.map((t) => (
              <span key={t} className="px-3 py-1 text-xs font-medium border rounded-full bg-blue-50 text-blue-700 border-blue-100">
                #{t}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}