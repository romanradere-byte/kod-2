"use client";

import { useMemo, useState } from "react";
import BookCard from "@/components/catalog/BookCard";
import { BOOKS } from "@/data/books";
// провірити чи є іконка 
import { Search } from "lucide-react";

export default function HomePageOld() {
  const [search, setSearch] = useState("");
  const [selectedTag, setSelectedTag] = useState<string | null>(null);

 const allTags = useMemo(() => {
  return Array.from(new Set(BOOKS.flatMap((b) => b.tags))).sort((a, b) =>
    a.localeCompare(b, "uk", { sensitivity: "base" })
  );
}, []);


  const filtered = BOOKS.filter((b) => {
    const matchSearch =
      b.title.toLowerCase().includes(search.toLowerCase()) ||
      b.author.toLowerCase().includes(search.toLowerCase());

    const matchTag = selectedTag ? b.tags.includes(selectedTag) : true;

    return matchSearch && matchTag;
  });

  return (
    <div className="flex flex-col md:flex-row gap-6 p-6 min-h-screen bg-gray-50">
      {/* SIDEBAR */}
      <aside className="w-full md:w-56 shrink-0">
        <div className="bg-white border border-gray-200 shadow-sm rounded-xl p-4 space-y-2 sticky top-6">
          <div className="font-bold text-gray-700 mb-4 px-3 uppercase text-xs tracking-wider">
            Категорії
          </div>

          <button
            onClick={() => setSelectedTag(null)}
            className={`block w-full text-left px-3 py-2 rounded-lg transition-colors ${
              selectedTag === null
                ? "bg-blue-600 text-white shadow-md"
                : "text-gray-600 hover:bg-gray-100"
            }`}
          >
            Всі книги
          </button>

          {allTags.map((tag) => (
            <button
              key={tag}
              onClick={() => setSelectedTag(tag)}
              className={`block w-full text-left px-3 py-2 rounded-lg transition-colors ${
                selectedTag === tag
                  ? "bg-blue-600 text-white shadow-md"
                  : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              {tag}
            </button>
          ))}
        </div>
      </aside>

      {/* CONTENT */}
      <div className="flex-1 space-y-6">
        {/* SEARCH BAR AREA */}
        <div className="relative max-w-md group">
          <Search 
            className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-blue-500 transition-colors" 
            size={18} 
          />
          <input
            className="w-full bg-gray-200 border border-gray-300 text-gray-900 placeholder-gray-500 rounded-xl pl-10 pr-4 py-3 outline-none focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all shadow-inner"
            placeholder="Пошук назви або автора..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        {/* RESULTS GRID */}
        {filtered.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filtered.map((book) => (
              <BookCard key={book.id} book={book} />
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-white rounded-xl border border-dashed border-gray-300">
            <p className="text-gray-500">Нічого не знайдено за вашим запитом</p>
            <button 
              onClick={() => {setSearch(""); setSelectedTag(null);}}
              className="mt-2 text-blue-600 hover:underline text-sm"
            >
              Скинути фільтри
            </button>
          </div>
        )}
      </div>
    </div>
  );
}