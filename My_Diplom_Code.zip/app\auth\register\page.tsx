"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";

export default function RegisterPage() {
  const router = useRouter();
  const { register } = useAuth();

  const [name, setName] = useState("");
  const [surname, setSurname] = useState("");
  const [group, setGroup] = useState("");
  const [password, setPassword] = useState("");

  function submit(e: React.FormEvent) {
    e.preventDefault();

    register({
      name: name + " " + surname,
      group,
      password,
      role: "STUDENT",
    });

    router.push("/");
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      <h1 className="text-2xl font-bold text-center">Реєстрація</h1>

      <input
        className="w-full border rounded px-3 py-2"
        placeholder="Імʼя"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />

      <input
        className="w-full border rounded px-3 py-2"
        placeholder="Прізвище"
        value={surname}
        onChange={(e) => setSurname(e.target.value)}
      />

      <input
        className="w-full border rounded px-3 py-2"
        placeholder="Група"
        value={group}
        onChange={(e) => setGroup(e.target.value)}
      />

      <input
        type="password"
        className="w-full border rounded px-3 py-2"
        placeholder="Пароль"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />

      <button className="w-full bg-blue-600 text-white py-2 rounded">
        Зареєструватися
      </button>
    </form>
  );
}
