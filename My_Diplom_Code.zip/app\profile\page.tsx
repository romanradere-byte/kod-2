"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { getFavorites } from "@/services/favorites.service";
import { Book } from "@/types/book";
import { useAuth } from "@/context/AuthContext";
import { useRouter } from "next/navigation";

export default function ProfilePage() {
  const { user } = useAuth();
  const router = useRouter();

  const [books, setBooks] = useState<Book[]>([]);

  useEffect(() => {
    if (!user) {
      router.push("/auth/login");
      return;
    }

    setBooks(getFavorites());
  }, [user]);

  if (!user) return null;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Мій профіль</h1>

      <div className="p-4 bg-white border rounded-xl">
        <div><b>Імʼя:</b> {user.name}</div>
        <div><b>Роль:</b> {user.role}</div>
      </div>

      <div>
        <h2 className="text-xl font-semibold mb-4">❤️ Збережені книги</h2>

        {books.length === 0 && (
          <div className="text-gray-500">Немає збережених книг</div>
        )}

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {books.map((book) => (
            <Link
              key={book.id}
              href={`/books/${book.id}`}
              className="border rounded-lg overflow-hidden bg-white hover:shadow"
            >
              <img
                src={book.cover}
                className="h-48 w-full object-cover"
              />
              <div className="p-2">
                <div className="font-semibold text-sm">{book.title}</div>
                <div className="text-xs text-gray-500">{book.author}</div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
