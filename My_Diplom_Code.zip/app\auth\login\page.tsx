"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";

export default function LoginPage() {
  const { login } = useAuth();
  const router = useRouter();

  const [name, setName] = useState("");
  const [password, setPassword] = useState("");

  const submit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!name || !password) {
      alert("Введіть імʼя та пароль");
      return;
    }

    login(name, password);
    router.push("/");
  };

  return (
    <form onSubmit={submit} className="space-y-4">
      <h1 className="text-2xl font-bold text-center">Вхід</h1>

      <input
        className="w-full border p-2 rounded"
        placeholder="Імʼя Прізвище"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />

      <input
        type="password"
        className="w-full border p-2 rounded"
        placeholder="Пароль"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />

    <button className="w-full bg-blue-600 text-white py-2 rounded">
  Увійти / Зареєструватися
</button>
    </form>
  );
}
